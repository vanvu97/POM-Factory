package core;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class WebDriverCore {

    public static WebDriver driver;
    private static WebDriverWait wait;
    protected static JavascriptExecutor js;
    private static int seconds = 30;
    public WebDriver setBrowser(String browserType,String URL) {
        switch (browserType.trim().toLowerCase()) {
            case "edge" -> driver = edgeBrowser(URL);
            case "firefox" -> driver = firefoxBrowser(URL);
            case "chrome" -> driver = chromeBrowser(URL);
            default -> {
                System.out.println("Browser: " + browserType + " is not config, starting default Browser...!");
                driver = edgeBrowser(URL);
            }
        }
        return driver;
    }

    private static WebDriver edgeBrowser(String URL) {
        EdgeOptions options = new EdgeOptions();
        WebDriverManager.edgedriver().setup();
        options.addArguments("--remote-allow-origins=*");
        driver = new EdgeDriver(options);
        driver.get(URL);
        common(driver, URL);
        return driver;
    }

    private static WebDriver firefoxBrowser(String URL) {
        FirefoxOptions options = new FirefoxOptions();
        WebDriverManager.firefoxdriver().setup();
        options.addArguments("--remote-allow-origins=*");
        driver = new FirefoxDriver(options);
        common(driver, URL);
        return driver;
    }

    private static WebDriver chromeBrowser(String URL) {
        ChromeOptions options = new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        options.addArguments("--remote-allow-origins=*");
        driver = new ChromeDriver(options);
        common(driver, URL);
        return driver;
    }
    public static void common(WebDriver driver, String URL){
        driver.manage().window().maximize();
        driver.get(URL);
        wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
        js = (JavascriptExecutor) driver;
    }
}
