package core.helper;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.util.Properties;

public class PropertiesManager {

    private static Properties properties;
    private static final String propertiesFilePath = Paths.get(System.getProperty("user.dir"),
            "src/test/resources", "Configuration.properties").toString();


    /**
     * Set the value to Properties file before or after run test
     *
     * @method setPropertiesFile
     * @since 1.0.0
     * @author Van Vu
     *
     */
    public static void setPropertiesFile() {
        properties = new Properties();
        try {
            FileInputStream fis = new FileInputStream(propertiesFilePath);
            properties.load(fis);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println(e.getCause());
            e.printStackTrace();
        }
    }
    /**
     * Get the value to Properties file before run test
     *
     * @method getPropValue
     * @param keyProp
     * @since 1.0.0
     * @author Van Vu
     *
     */
    public static String getPropValue(String keyProp) {
        String value = null;
        try {
            value = properties.getProperty(keyProp);
            return value;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println(e.getCause());
            e.printStackTrace();
            return null;
        }
    }
    /**
     * Set the value to Properties file before or after run test
     *
     * @method setPropValue
     * @param keyProp
     * @param value
     * @since 1.0.0
     * @author Van Vu
     *
     */
    public static void setPropValue(String keyProp, String value) {
        try {
            FileOutputStream fos = new FileOutputStream(propertiesFilePath);
            properties.setProperty(keyProp, value);
            properties.store(fos, "Set up new value for: " + value + "!");
            System.out.println("Set up new value for: " + value + "!");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println(e.getCause());
            e.printStackTrace();
        }
    }
}
