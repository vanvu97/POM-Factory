package core.helper;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import java.io.File;
import java.util.Date;

import static core.helper.Logs.setExtentTest;

public class Report {
    private static ExtentReports extent;
    private static ExtentTest test;
    private static Date date = new Date();
    public static void extentReport(String getClassName){
        String reportName = getClassName+ " " + date.toString().replace(":", "-") + ".html";
        var htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + File.separator + "Report" + File.separator + reportName);
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        test = extent.createTest(getClassName);
        setExtentTest(test);
    }
    public static void closeReport(){
        extent.flush();
    }
}
