package core;

import core.helper.PropertiesManager;
import org.testng.annotations.*;
import core.helper.TestListener;
import static core.helper.Report.closeReport;
import static core.helper.Report.extentReport;


@Listeners(TestListener.class)
public class BaseTests extends WebDriverCore {

    @Parameters({"browserType", "URL"})
    @BeforeSuite
    public void beforeSuit(String browserType, String URL) {
        setBrowser(browserType, URL);
        extentReport(this.getClass().getSimpleName());
    }

    @BeforeTest
    public void initTest() {
        PropertiesManager.setPropertiesFile();
//        setupBrowser(PropertiesManager.getPropValue("browserType"));
    }

    @AfterTest
    public void endTest() {
        driver.close();
    }

    @AfterSuite
    public void afterSuit() {
        closeReport();
    }

}

