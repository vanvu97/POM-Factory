package pages;

import core.BasePage;
import locator.Locator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import core.helper.ValidateAction;
import core.helper.Logs;
import utils.Action;

public class LoginPage extends BasePage {

    private By getPageTitle = By.xpath("//div[@class='title']/div[2]");
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public LoginPage loginWeb(String username, String password) {
        Logs.info("Input Username: " + username);
        ACTION.setText(Locator.USERNAME, username);

        Logs.info("Input password: " + password);
        ACTION.setText(Locator.PASSWORD, password);

        Logs.info("Click Login");
        ACTION.click(Locator.BTN_SUBMIT);
        return this;
    }
    public CustomDashboardPage verifyLoginSuccessful(){
        Logs.info("Verify page title");
        ACTION.assertText("Single System - Dashboard", getPageTitle);
        return new CustomDashboardPage(driver);
    }

}
