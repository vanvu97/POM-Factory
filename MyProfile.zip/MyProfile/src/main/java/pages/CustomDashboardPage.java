package pages;

import core.BasePage;
import data.Constants;
import locator.Locator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import core.helper.Logs;
import core.helper.ValidateAction;
import utils.Action;

public class CustomDashboardPage extends BasePage {

    private final By menuIcon = By.xpath("//i[@class='gx-icon-btn icon icon-menu-unfold']");
    private final By getPageTitle = By.xpath("//div[@class='title']/div[2]");
    private final By settingIcon = By.xpath("//span[@aria-label='setting']");
    private final By checkFilterDomain = By.xpath("//div[@class='Wrapper_selector-wrapper__8Zp63']/div/div/div/div/label");
    private final By closeGlobalFilterBtn = By.xpath("//div[contains(@class, 'Header_selector-header__H6RE4')]//span[@aria-label='close']");
    private final By shapeTitle = By.xpath("//div[@class='Container_dashboard-wrapper__549FV Container_LIGHT__uefoN']//div[contains(@class, '-title__')]/div[1]");
    private final By getCreateDashboardBtn = By.xpath("//div[@class='EmptyCustom_create-dashboard__Qwzjy']");
    private final By dashboardTemplatePopup = By.xpath("//div[@class='Template_create-title__GrsTG']");
    private final By templateTitle = By.xpath("//div[@class='Template_template-title__f47UN']");
    private final By widgetTitle = By.xpath("//div[@class='WidgetList_widget-title__GyH5Z']");
    private final By isWidgetEmpty = By.xpath("//div[@class='Empty_empty-text__cu5nk']");
    private final By widgetPopupTitle = By.xpath("//div[@class='ant-modal-title']");
    private final By dataTypeField = By.xpath("//span[@class='ant-select-selection-item']");
    private final By dataTypeValues = By.xpath("//div[@class='ant-select-item-option-content']");
    public final By CUSTOM_DASHBOARD_PAGE = By.xpath("//ul[contains(@class, 'ant-menu')]/li[2]");
    public CustomDashboardPage(WebDriver driver) {
        super(driver);
    }
    public CustomDashboardPage navigateToCustomDashboard() {
        Logs.info("Open left side panel");
        ACTION.click(menuIcon);

        Logs.info("Navigate to Custom Dashboard page!");
        ACTION.click(CUSTOM_DASHBOARD_PAGE);
        return this;
    }

    public CustomDashboardPage verifyCustomDashboardIsOpened(){
        Logs.info("Verify the Custom Dashboard page is opened");
        ACTION.assertText("Custom Dashboard", getPageTitle);
        return this;
    }

    public CustomDashboardPage filterAllDomain(){
        Logs.info("Click on Setting icon");
        ACTION.click(settingIcon);

        Logs.info("Check on checkbox filter Domain");
        ACTION.click(checkFilterDomain);

        Logs.info("Close filter panel");
        ACTION.click(closeGlobalFilterBtn);
        return this;
    }

    public CustomDashboardPage verifyInitialCustomDashboard(){
        Logs.info("Is the Create Dashboard button is displayed?");
        if(ACTION.isExisting(getCreateDashboardBtn)){
            Logs.info("No, Create Dashboard button is displayed, Click Create Dashboard button");
            ACTION.click(getCreateDashboardBtn);
            verifyDashboardTemplatePopupIsDisplayed();
            createCustomDashboard("New Dashboard");
        }else {
            Logs.info("Yes, Custom Dashboard already existed, getting listTemplateTitle of shape's name");
            ACTION.getListText(shapeTitle);
        }
        return this;
    }

    public CustomDashboardPage verifyDashboardTemplatePopupIsDisplayed(){
        Logs.info("Verify Choose Dashboard Template pop-up is displayed?");
        if(ACTION.isExisting(dashboardTemplatePopup)){
            Logs.info("Verify Choose Dashboard Template pop-up title!");
            ACTION.assertText("Choose Dashboard Template", dashboardTemplatePopup);

            Logs.info("Verify title of template list!");
            String [] listTemplateTitle = Constants.listTemplateTitle;
            ACTION.assertListText(templateTitle, listTemplateTitle);
        }
        return this;
    }

    public CustomDashboardPage createCustomDashboard(String customDashboard){
        Logs.info("Select Custom Dashboard: " + customDashboard);
        ACTION.click(Locator.selectDashboardTemplate(customDashboard));

        Logs.info("Is Widget of Custom Dashboard is empty when select " + customDashboard);
        if(ACTION.isExisting(isWidgetEmpty)){
            Logs.info("Yes, Widget of Custom Dashboard is empty");
            ACTION.assertText("Click to place widget!", isWidgetEmpty);
        }

        String [] listWidgetTitle = Constants.listWidgetTitle;
        Logs.info("Verify list widget name is correct!");
        ACTION.assertListText(widgetTitle, listWidgetTitle);
        return this;
    }

    public CustomDashboardPage verifyPopupWidget(String widgetName, String popupTitle, String[] listDataType){
        Logs.info("Click on " + widgetName + " button");
        ACTION.click(Locator.selectWidgetName(widgetName));

        Logs.info("Verify the " + popupTitle + " pop-up is displayed");
        ACTION.assertText(popupTitle, widgetPopupTitle);

        Logs.info("Verify the Data Type of " + widgetName);
        ACTION.click(dataTypeField);
        ACTION.assertListText(dataTypeValues, listDataType);
        return this;
    }
}
