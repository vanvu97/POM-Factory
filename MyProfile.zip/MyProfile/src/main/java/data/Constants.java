package data;

public class Constants {
    public static final String [] listTemplateTitle = {"Application", "Custom Default", "Dashboard", "Dashboard-lld2oe8b", "EndUser", "Host", "New Dashboard"};
    public static final String [] listWidgetTitle = {"Active Service Histogram", "Active Services", "Alerts", "Application"
            , "DB Connection Pool", "EndUser Xlog", "Flow", "Host", "Navigation Timing", "Page Performance", "Performance"
            , "Script Error Count", "Service", "User Sessions", "Worldwide Response Time", "Xlog", "bar", "dataTable"
            , "line", "list", "number", "textBox"};
    public static final String [] listDataTypeOfLine = {"Application", "Host", "EndUser"};
}
