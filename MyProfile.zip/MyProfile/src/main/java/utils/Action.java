package utils;

import core.helper.ValidateAction;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Action extends ValidateAction {
    public Action(WebDriver driver) {
        super(driver);
    }

    @Override
    public void scrollToJS(By element) {
        super.scrollToJS(element);
    }

    @Override
    public void click(By element) {
        super.click(element);
    }

    @Override
    public void setText(By element, String text) {
        super.setText(element, text);
    }

    @Override
    public void getText(By element) {
        super.getText(element);
    }

    @Override
    public void getListText(By element) {
        super.getListText(element);
    }

    @Override
    public boolean isExisting(By element) {
        return super.isExisting(element);
    }

    @Override
    public void assertTitle(String expected) {
        super.assertTitle(expected);
    }

    @Override
    public void assertText(String expected, By element) {
        super.assertText(expected, element);
    }

    @Override
    public void clickJS(By element) {
        super.clickJS(element);
    }

    @Override
    public void assertListText(By element, String[] expectedText) {
        super.assertListText(element, expectedText);
    }

    @Override
    public void waitForPageLoad() {
        super.waitForPageLoad();
    }
}
